Rhiven - Radiant Prostitution Fix V0.1 - SOURCE TEST ONLY

Target: NEFARAM / mf_handler.psc; preserves script name mf_Handler.
Do not deploy to an active MO2 profile; this is not yet compiled.

Changes (PerformSex + fuck only):
 - Max 15 s wait for actor availability; check SexLab.ValidateActor() == 1.
 - Check NewThread() and AddActor() return values; no .StartThread() on None.
 - On AddActor() failure, call Initialize() only for own thread in Making state.
 - Check StartThread() result; do not force-reset a thread outside Making.
 - Move client count / refractory updates to after accepted StartThread().
 - Trace prefix: [RHI_RP].

Not modified: PerformThreesome(), PerformCreatureSex(), PerformMasturbation().
Status: drafted; NOT compile-tested / NOT game-tested.
Build environment still has dependency errors. The helper FNIS.psc made
for compilation must NEVER be installed into MO2/game.

Review the changed source and compile in an isolated test output before use.
