ELEANOR RTC SETTINGS - RHIVEN / PRESET EXPERIMENTAL

Install folder: SKSE/Plugins/RapeTattoos/99-Eleanor-RTC.json
Requires Rape Tattoos Continued 2.0.3 + QoL Extension rev1, and the active Alpia and Zaki settings presets.

- Excluded Alpia themes: BBC, Cow, Dog, Dragonwhore breeding, Horse Breeding, Kitten.
- Existing author exclusions outside those themes preserved, except Full variants enabled by request.
- 51 originally excluded Full entries in retained collections are unlocked; Full face/head variants use face/forehead, full body uses dedicated full body group.
- Group names from retained Alpia entries normalized to lowercase where needed to match Zaki.
- Zaki group choices and non-Full Alpia exclusions kept intact. No Overlap reassignments not imported blindly.
- QoL merges presets based on file name/order; validate via MCM Test/Reload configs and in-game save testing.
- Group limit and RTC targeting/chance must be set via RTC MCM; this JSON is not PC-only.
- No true geometric overlap prevention; full-body overlaps accepted.
- No beast/orc/riekling optional packs installed.

Do not rename preset to settings.json. Backup existing mods before testing.
