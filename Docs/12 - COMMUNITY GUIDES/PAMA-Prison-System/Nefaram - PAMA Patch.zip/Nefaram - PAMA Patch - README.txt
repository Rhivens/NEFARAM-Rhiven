Nefaram - PAMA Patch.esp
========================
Author: valkaras (LoversLab)
One ESL-flagged (light) patch for the PAMA Prison System on NEFARAM.
Built from Rhiven's PAMA guide (github.com/Rhivens/NEFARAM-Rhiven,
Docs/12 - COMMUNITY GUIDES/PAMA-Prison-System) on an OLDER NEFARAM build.
No new records - 29 overrides only. Uses 0 full plugin slots.

REPLACES (do not install together with):
  - PAMA - Windhelm Navmesh Patch - Rhiven.esp
  - PAMA - Solitude Location Patch - Rhiven.esp
  - Falkreath LAND - Rhiven Fix.esp
Keep "PAMA - NEFARAM ZaZ Ankle Chains Patch - Rhiven" (mesh only).

CONTENTS
  - Windhelm navmeshes 04B66C / 0FC117 -> CWE-SkyrimSewers / WindhelmSSE
    Exterior NavMesh Fixes versions (same as Rhiven's Windhelm patch).
  - SolitudeOrigin / Windhelm Candlehearth Hall exterior keep their
    location (XLCN) (same as Rhiven's Solitude patch).
  - Falkreath LAND 0AC81 (same as Rhiven's fix) PLUS 0AC82, 0ACA2, 0ACA3:
    PaOutdoorEventPack carries vanilla terrain for all four cells, which
    flattens Northern Roads / CotN Falkreath. All four restored to
    "Northern Roads - CotN Falkreath - LFFGM patch".
  - Navmeshes 0E8088 (Morthal), 102F53 (Dawnstar), 105917 (Falkreath):
    PaPunishmentPack1.esp ships byte-identical vanilla copies (ITMs) that
    wipe the Cities of the North navmeshes. Restored to CotN versions.
  - 7 hold crime factions: NiftyAITweaksAIO version with the jail outfit
    (JOUT) removed again, as Prison Alternative intends.
  Parent worldspace/cell records are copied from the build's Synthesis_3
  (Occlusion.esp / DynDOLOD.esp override them afterwards).

MASTERS
  Skyrim.esm, Update.esm, Landscape Fixes For Grass Mods.esp,
  SkyrimSewers.esp, WindhelmSSE.esp, COTN - Falkreath.esp,
  Water for ENB (Shades of Skyrim).esp, Northern Roads.esp
  (plus CotN Morthal/Dawnstar, Environs AA and Nifty AI Tweaks data copied in).

LOAD ORDER
  - AFTER all 7 PAMA ESPs (PamaSovngardeAftermath, PaPunishmentPack1,
    PaOutdoorEventPack, PrisonAlternative_Executions_WindHelm/_Riften/
    _Solitude, OrkishBountyHunters) - otherwise they win the LAND/NAVM
    records again.
  - BEFORE DynDOLOD.esp and Occlusion.esp (they must stay last).
  - Tested placement: directly after "Nefaram - DP Ravenous Patch.esp",
    i.e. after Synthesis_0-4.

COMPATIBILITY NOTE
  Records were copied from a specific (older) NEFARAM build. On a newer
  NEFARAM version, check in xEdit that the CotN / Northern Roads / Nifty AI
  Tweaks / Synthesis sources still match before using it.

Tested: load order verified, Deadly Furniture test zone (coc pamaTestZone)
and in-game PAMA flow OK. Untested: Riften well clipping the PAMA scaffold
(Rhiven: console-click the well, then "disable").
